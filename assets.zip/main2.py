from PyQt6 import QtWidgets, uic
from PyQt6.QtCore import QTimer, Qt, QPoint
from PyQt6.QtGui import QAction, QIcon, QPixmap
from PyQt6.QtWidgets import QMessageBox, QMenu, QSystemTrayIcon, QPushButton,QToolBar

import sys
import os
from threading import Thread
from src.core.log import init_logging
import time

try:
    from src.core.config import Config    
    CONFIG_FILE = True
    ERR_VALUE = None
except Exception as e:
    ERR_VALUE = str(e)
    CONFIG_FILE = False

if CONFIG_FILE:
    from src.core.app import App
    
    from misc.client_sample import ClientSimulator
    from misc.ui_intellisense import UiWidgets

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

main_ui_path = resource_path('assets/ui/main.ui')
icon_tray = resource_path('assets/icon.png')

class FocuserOPD(QtWidgets.QMainWindow):
    def __init__(self):
        super(FocuserOPD, self).__init__()
        uic.loadUi(main_ui_path, self)
        self.second_window = None

        if not CONFIG_FILE:
            close = QMessageBox()
            close.setText(f"Arquivo de configuração com problemas!\n{ERR_VALUE}")
            close.setStandardButtons(QMessageBox.Ok)
            close = close.exec()

            if close == QMessageBox.Ok:   
                sys.exit()

        # self.control = App(logger)

        self.config_file = r"src/config/config.toml"
        self.log_file = r"logs/focuser.log"

        # Creates "ui_elements" widget to hold intellisense references to the widgets
        self.ui_elements = UiWidgets(self)
        
        self.ui_elements.actionShow_toolbar.triggered.connect(              
            lambda checked: self.ui_elements.toolBar.setVisible(checked)    # Action to toggle toolbar
            )   

        
        


if __name__ == "__main__":

    logger = init_logging() 
    app = QtWidgets.QApplication([])       

    main_window1 = FocuserOPD()
    main_window1.show()
    

    sys.exit(app.exec()) 