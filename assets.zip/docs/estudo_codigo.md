# Server

## Config

Arquivo `config.toml` possui as configurações que serão aplicadas ao código durante a inicialização.

Em `config.py` é definida a classe `Config`, que basicamente é uma estrutura que armazena essas configurações do arquivo `config.toml` em um formato que pode ser utilizado no código de forma mais fácil.


## main.py

Realiza as ações relacionadas com a interface gráfica da tela principal, da tela de log e da tela de configuração. Também possui o loop principal que será chamado a cada 100ms.

Define a classe `FocuserOPD`, que possui todos os métodos que serão executados durante o código. Essa classe herda de `QtWidgets.QMainWindow`.



Inicialmente é feita a inicialização do logger, através da função `init_logging()` disponível em `log.py`. Para o logger é utilizada a biblioteca `logging`, então basicamente é realizada a configuração de acordo com a biblioteca.

> **Logger** _logger_

A aplicação é definida através da variável `app`, isso é necessário para a execução da interface gráfica pelo Qt.

Em seguida a tela principal vai ser criada como sendo da classe `FocuserOPD`, e a tela é iniciada pelo comando `main_window1.show()`.

#### class FocuserOPD(QtWidgets.QMainWindow)

A inicialização de `FocuserOPD` vai realizar a configuração dos elementos da interface gráfica, inicializar algumas variáveis, checar a conexão através de um `ping` e, caso `Config.startup == true` vai iniciar o servidor.

As principais variáveis inicializadas são:

- `self.control = App(logger)`: A classe `App` é definida em `app.py` e vai possuir todos os métodos relacionados com a comunicação 0MQ e as ações de controle do focalizador.

- `self.config_file`: Caminho para o arquivo de configuração.

- `self.log_file`: Caminho para o arquivo atual de log.

Métodos de `FocuserOPD`:

- `minimize_to_tray`: Minimiza o programa na bandeja, removendo ele da barra de tarefas.

- `restore_from_tray`: Retorna o programa para a barra de tarefas quando se utiliza o botão direito do mouse no ícone.

- `tray_activated`: Mesma coisa que `restore_from_tray` mas quando ocorre duplo clique no ícone.

- `run_simulator`: Cria e abre a janela do simulador de cliente, da classe `ClientSimulator`.

- `start`: Verifica se o servidor já está em execução, e caso não esteja cria uma nova thread e inicia o servidor. A execução do servidor é realizada por `self.control.run`, definida em `app.py`.

- `stop`: Encerra todas as comunicações do 0MQ e envia o comando para encerrar o loop principal, em seguida roda `self.run_thread.join()` para aguardar a finalização do loop principal.

- `toggle_config_view`: Mostra a tela de configuração.

- `read_config_file`: Faz a leitura do arquivo de configuração para mostrar na tela.

- `save_config_file`: Salva as alterações no arquivo de configuração.

- `toggle_log_view`: Mostra a tela para visualizar o arquivo de LOG atual.

- `read_log_file`: Abre o arquivo de LOG atual.

- `ping`: Verifica se o dispositivo está alcançável. Na verdade não roda nenhum método para fazer um ping mesmo, somente atualiza a interface gráfica de acordo com o estado de `self.control.reachable` e `self.control.router`, que são atualizadas no método `reach_device` de `app.py`.

- `update`: Loop principal e gerenciador da interface gráfica, no construtor de `FocuserOPD` o método `update` é configurada para ser executada a cada 100ms. Nesse método a variável `self.control.status` é utilizada para realizar as atualizações na interface gráfica. `self.control.status` é atualizada nos métodos da classe `App` conforme a execução do programa. O status da conexão é atualizado a cada 15 segundos através da chamada do método `ping` (pelo código parece que é 10 segundos).

- `closeEvent`: Abre uma janela para garantir que o usuário quer mesmo sair do programa. Se confirmado as conexões são encerradas através da chamada do método `stop` e o programa é encerrado.



## App.py

Responsável pelas operações de conexão com os sockets e gerenciamento das ações de controle.


#### class App()

No construtor de `App()` é realizada a inicialização de variáveis, sendo algumas delas iniciadas de acordo com os valores configurados no arquivo `config.toml`. Por fim é realizada uma tentativa de conexão com o dispositivo e a inicialização do servidor.

As principais variáveis inicializadas são:

- `self.status`: Dicionário utilizado para armazenar as informações com o estado atual do motor e do sistema. No método `pub_status` é transformada em um JSON e a informação é publicada no 0MQ.

- `self.device = Focuser(self.logger)`: Objeto de driver do motor. A classe `FocuserDriver` é definida em `dmx_eth.py` e possui os métodos para a comunicação com o motor, possibilitando a leitura de status e envio de comandos.

Métodos de `App`:

- `reach_device`: Verifica a conexão com o motor e com o roteador. Caso a conexão com o motor seja bem sucedida atualiza `self.status["position"]` e `self.status["initialized"]`.

- `start_server`: Caso um contexto não tenha sido criado cria uma conexão 0MQ. Reliza o _binding_ para PUB e REP de acordo com o Ip e as portas configuradas em `config.toml`. Também inicia o poller do REP e por fim publica o status atual através do método `pub_status`.

- `close_connection`: Desfaz o _binding_ dos _sockets_ e destrói o contexto da conexão do 0MQ.

- `disconnect`: Para o loop principal e fecha as conexões.

- `pub_status`: Transforma `self.status` em um JSON e envia através do 0MQ.

- `stop`: Manda o comando para encerrar o loop principal (`self.stop_var = True`) e para o poller do 0MQ.

- `ping_server`: Verifica se é possível se conectar ao motor. Para isso é aberto um socket com o motor, que em seguida é fechado.

- `ping_router`: Verifica se é possível se conectar com o roteador. Para isso é aberto um socket na porta 80 do roteador, que em seguida é fechado.

- `handle_home`: Envia para o motor o comando `HOME` e verifica se o comando foi bem sucedido, alterando `self.status` de acordo com a resposta.

- `handle_halt`: Envia para o motor o comando `HALT` e verifica se o comando foi bem sucedido.

- `handle_speed`: Envia para o motor o comando para alterar a velocidade e verifica se o comando foi bem sucedido. São feitas checagens para evitar valores maiores que `Config.max_speed` e valores negativos

- `handle_connect`: (**deprecated**) Só coloca no logger que o dispositivo está conectado.

- `handle_disconnect`: (**deprecated**) Só coloca no logger que o dispositivo está desconectado.

- `handle_in_out`: Envia para o motor o comando `FOCUSIN` ou `FOCUSOUT` de acordo com o parâmetro `direction` (`1 for IN, 0 for OUT`). A verificação de comando bem sucedido é feita por exceção, que atualiza `self.status`, o logger e publica o status.

- `handle_move`: Envia para o motor o comando para mover para uma posição específica. A verificação de comando bem sucedido é feita por exceção, que atualiza `self.status`, o logger e publica o status.

- `update_status`: Verifica se ocorreu alguma mudança nas variáveis de estado (`_position`, `_is_moving`, `_homing`) e caso alguma alteração tenha ocorrido atualiza e publica `self.status`.

- `reply`: Envia resposta no REP do 0MQ com uma mensagem. Utilizado para responder com `ACK` ou `NAK` se o comando tiver sido ou não tiver sido reconhecido.

- `run`: Loop principal. 
    - Garante que o server foi iniciado;
    - Atualiza `self.status["connected"]`;
    - Entra em loop infinito enquanto `self.stop_var == false`;
        - A cada 1 segundo atualiza a posição do motor e publica o valor;
        - Se o dispositivo estiver definido e conectado e o poller registrado:
            - Faz o polling (_timeout=50ms_) e verifica se alguma mensagem foi recebida, faz a leitura da mensagem recebida e faz o _parsing_ para verificar o comando recebido;
            - Um comando diferente de `STATUS` somente será aceito se o motor não estiver ocupado ou se tiver sido requisitado pelo mesmo cliente;
            - Se o comando for aceito é verificado qual comando foi enviado e a função referente a esse comando é executada. Os comandos são executados através de chamadas de funções para o driver do motor em `dmx_eth.py`;
            - Se o comando tiver sido processado normalmente é respondido um `ACK` para o cliente, senão é respondido um `NAK`;
            - Caso alguma exceção ocorra durante a execução do comando é realizada uma publicação do status e o erro que ocorreu é salvo no logger;
            - Verifica se o motor está em movimento ou se a rotina de _homing_ está sendo executada. Se nenhuma dessas rotinas estiver sendo executada é considerado que o motor não está ocupado (`self.client_id = 0`).
            - Por fim o status é atualizado e o sinal de alarme é colocado em 0.
        - No caso do dispositivo não estar definido ou não estiver conectado ou o poller não estar registrado:
            - Executa o método `self.reach_device` a cada 7 segundos para verificar a conexão e a posição atual do motor.



## dmx_eth.py

Driver para o motor utilizado no focalizador. Responsável por enviar os comandos e ler as variáveis de interesse da memória.

### class FocuserDriver()


Propriedades e métodos de `FocuserDriver`:

- `connected`:  
    - `getter`: Lê o valor do status de conexão do motor (`_connected`).
    - `setter`: [true] Conecta o motor e abre um socket para comunicação / [false] Chama o método `disconnect` para desconectar o motor e fechar o socket.

- `disconnect`: Fecha a conexão do socket de comunicação com o motor.

- `temp`:
    - `getter`: Lê o valor de `_temp`.
    - `setter`: não implementado.

- `temp_comp_available`:
    - `getter`: Lê o valor de `_temp_comp_available`.
    - `setter`: não implementado.

- `temp_comp`:
    - `getter`: Lê o valor de `_temp_comp`.
    - `setter`: Modifica o valor de `_temp_comp`.

- `position`:
    - `getter`: Manda para o motor o comando para leitura da posição do encoder, converte o resultado para mícrons e salva o valor em `_position`. Também salva a posição em `_last_pos`.

- `is_moving`: :exclamation:
    - `getter`: Faz a leitura da posição de memória `V46` do motor para checar se o motor está em movimento e atualiza `_is_moving`.

- `homing`: :exclamation:
    - `getter`: Faz a leitura da posição de memória `V44` do motor para checar se a rotina de homing está sendo executada e atualiza `_is_homing`.

- `initialized`: :exclamation:
    - `getter`: Faz a leitura da posição de memória `V44` do motor para checar se a rotina de inicialização foi executada e atualiza `_initialized`.

- `get_status`:
    - `getter`: Envia para o motor o comando `GS0` para solicitar o estado atual e atualiza `_status`.

- `absolute`:
    - `getter`: Retorna o valor de `_absolute`.

- `max_increment`:
    - `getter`: Retorna o valor de `_max_increment`.

- `max_step`:
    - `getter`: Retorna o valor de `_max_step_`.

- `step_size`:
    - `getter`: Retorna o valor de `_step_size`.

- `alarm`:
    - `getter`: Manda o comando `ALM` para o motor e atualiza `_alarm`.

- `home`: Envia para o motor o comando `GS30` para realizar a rotina de _homing_.

- `move`: Movimenta o motor para a posição solicitada em mícrons. Primeiro coloca na posição `V20` da memória do motor a posição para a qual se deseja mover o motor, em seguida envia para o motor o comando `GS29` para realizar a rotina de movimentação do motor. 

- `speed`: Seleciona a velocidade desejada para o movimento do motor. Salva na posição de memória `V21` o valor da velocidade desejada. 

- `focus_in_out`: Envia o comando para o motor para realizar a rotina de `FOCUSIN` (`GS21`) ou `FOCUSOUT` (`GS20`) de acordo com `direction`. 

- `stop`: Usado somente para alterar os valores de `_is_moving`, `_stopped` e parar o timer `_timer` depois da execução do método `Halt`.

- `Halt`: Realiza a parada de qualquer movimentação que esteja ocorrendo no motor. Escreve o valor `1` na posição de memória `V42` para realizar a parada imediata de qualquer movimentação do motor.

- `_write`: Envia comandos para o socket do motor e realiza a decodificação da resposta. 
