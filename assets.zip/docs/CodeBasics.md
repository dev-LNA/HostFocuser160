
# Sumário

* [Sobre o motor](#motor)
    * [Operação do motor](#operação-do-motor)
    * [Memória interna](#memória-interna)
* [Código Python](#código-python)

 
<br><br><br><br>

# Motor
Modelo do motor: [DMX-ETH](https://arcus-technology.com/products/integrated-stepper-motors/nema-17-integrated-ethernet-stepper/) 



## Operação do motor

A operação do motor é configurada através de programação realizada internamente no motor através de software proprietário.
Os códigos do motor estão na pasta `DMX-ETH\focuser pe160`.
A versão mais recente do código é a do arquivo `Focuser PE160 20240127.prg`.

O código foi feito pelo Francisco, e é responsável por realizar toda a operação do motor através de rotinas específicas.

A aplicação python realiza o envio dos comandos para o motor para a realização das rotinas que foram programadas. Além disso, é possível solicitar a leitura da memória interna do motor, na qual estão disponíveis diversas informações úteis para a aplicação.

A tabela abaixo mostra as rotinas implementadas:

| Rotina        |   Função                                                      | Comando           |
|:-------------:|:--------------------------------------------------------------|:-----------------:|
| GOTO          | Move o mecanismo para uma posição desejada (valor positivo)   | GS29              |
| STOP          | Para o movimento do motor                                     | V42=1             |
| STATUS        | Lê o status do motor                                          | GS0               |
| GET POSITION  | Retorna um valor negativo (Deve ser multiplicado por -1)      | EX                |
| GET FLAG BUSY/ERROR  | Status da condição de operação do motor                | V46               |
| GEY FLAG INIT DONE   | Se for =0 bloqueia a rotina GOTO                       | V44               |





O status do motor vai ser uma estrutura de 32 bits com a seguinte informação:

```
int track   :   8		// original track and error codes of V46. = V46&255
int index	:   5		// free parameter, =(V11&32)<<10
int eo      :   1		// motor driver state =(EO<<15)
int init    :   2		// INIT done flag, =(GFOCinit OTHERSinit)<<29
int status  :   9		// motor status, =(MST&511)<<16
int latch   :   2		// latch status
int io      :   4		// motor inputs&outputs states, =(DO2 DO1 DI2 DI1)<<25
```

A tabela abaixo mostra as configurações iniciais do motor:

| Posição de memória |   Informação                                                                 | Valor             |
|:------------------:|:-----------------------------------------------------------------------------|:-----------------:|
| V33                | Versão atual do firmware (S4DMX)                                             | 20240127          
| V50                | ID do motor                                                                  | 64
| V49                | ICS seta igual ao ID do motor para habilitar movimento (acho que não é usado)| 64                
| V71                | Máxima posição de target (Unidades do encoder)                               | 2165440                                       
| V74                | Correção para evitar `backlash` no movimento (5/8 rev)                       | 5360                                          
| HSPD               | Velocidade máxima do motor (pulsos/segundo)                                  | 250000 (Equivalente a 500 microns/segundo)    
| LSPD               | Velocidade mínima do motor (pulsos/segundo)                                  | 10000     
| ACC                | Aceleração do motor (msec)                                                   | 300    
| DEC                | Desaceleração do motor (msec)                                                | 300    
<br>

## Memória interna

O motor possui úma memória interna com 100 posições para informações `signed 32-bit` que podem ser utilizadas para armazenamento geral.

As posições 51~100 podem ser utilizadas para armazenamento em memória flash.

Para mais detalhes ver seção 7.16.6 do manual do motor.

As posições de memória sendo utilizadas são mostradas na tabela abaixo:

| Posição de memória |   Informação                                       | Valores             |
|:------------------:|:---------------------------------------------------|:-----------------:|
| V20                | Seta a posição                                     | 
| V21                | Seta velocidade                                    |
| V42                | Halt (Comando stop no Arcus)                       |
| V44                | INIT_FLAG (Indica se Homing já foi feito)          |
| V46                | Busy Ready Error (Verifica se está movimentando)   | 0=READY / 1=BUSY / ERROR_CODE

<br><br><br><br><br>


---
---
<br>

# Código Python

Para gerar o executável utilizar as configurações do arquivo `FocuserServer.spec` através do comando:

```
pyinstaller FocuserServer.spec
```

Para realizar debug o código pode ser rodado diretamente do VScode, dessa forma é possível verificar mensagens de erro pelo terminal.

A UI foi desenvolvida utilizando o [Qt Widgets Designer](https://doc.qt.io/qtforpython-6/tutorials/basictutorial/uifiles.html), no qual a interface gráfica é criada e cada um dos componentes recebem uma tag que pode ser utilizada no código.

A tabela a seguir indica os labels que são utilizados no código para se referir aos elementos visuais da tela principal `main.ui`:

| Label                 |   Elemento visual        | Funcionalidade        |
|:----------------------|:------------------------:|:----------------------|
| lblIP                 | Label                    | Mostra Ip do cliente
| lblPort               | Label                    | Mostra Ports usadas para Pub e Sub
| lblIP                 | Label                    | Mostra Ip do cliente
| lblPos                | Label                    | Mostra a posição atual do motor
| lblEnc                | Label                    | Mostra a posição atual do encoder
| lblPing               | Label                    | Mostra se o device foi encontrado na rede
| statMotor             | Label (lampada)          | Indica se o motor foi encontrado na rede
| statServer            | Label (lampada)          | Indica se o servidor está conectado
| statRouter            | Label (lampada)          | Indica se o roteador foi encontrado na rede
| boxLog                | CheckBox                 | Quando marcada faz aparecer a tela de log
| btnStart              | Botão                    | Inicializa o servidor
| btnStop               | Botão                    | Para a execução do loop principal
| btnHide               | Botão                    | Minimiza o programa para a barra oculta
| actionSettings        | Drop menu                | Abre a tela de configurações
| actionClientSimulator | Drop menu                | Abre o simulador de cliente

<br><br>
A tela de Log é configurada como um `QTextEdit` dentro de um `QDockWidget`.

A tela para configuração das configurações foi criada usando um `QTextEdit` e um `QPushButton` dentro de um `QDockWidget`.

Tanto a tela de log como a de configuração são colocadas como escondidas (hide) quanod a tela é criada, e são mostradas quando necessário.

Qual o motivo para não usar o QtDesigner para montar essas telas também? Só pq são telas mais simples?


[Comparação entre Qt Widgets e Qt Quick](https://www.brainzmagazine.com/post/qt-widgets-vs-qt-quick-a-comprehensive-comparison)


