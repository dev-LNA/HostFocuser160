from PyQt6.QtGui import QAction, QIcon
from PyQt6.QtWidgets import (
    QWidget, 
    QMessageBox, 
    QMenu, 
    QSystemTrayIcon, 
    QPushButton,
    QToolBar, 
    QLabel)




class UiWidgets(QWidget):
    def __init__(self, window):

        # uic.loadUi(main_ui_path, self)
        
        self.menuOptions = window.findChild(QMenu, 'menuOptions')
        self.menuOptions: QMenu = self.menuOptions

        self.actionHide = window.findChild(QAction, 'actionHide')
        self.actionHide: QAction = self.actionHide

        self.actionSettings = window.findChild(QAction, 'actionSettings')
        self.actionSettings: QAction = self.actionSettings

        self.actionShow_toolbar = window.findChild(QAction, 'actionShow_toolbar')
        self.actionShow_toolbar: QAction = self.actionShow_toolbar

        self.actionClient_Simulator = window.findChild(QAction, 'actionClient_Simulator')
        self.actionClient_Simulator: QAction = self.actionClient_Simulator

        self.actionShow_Log = window.findChild(QAction, 'actionShow_Log')
        self.actionShow_Log: QAction = self.actionShow_Log

        self.toolBar = window.findChild(QToolBar, 'toolBar')
        self.toolBar: QToolBar = self.toolBar

        self.ledServer = window.findChild(QLabel, 'ledServer')
        self.ledServer: QLabel = self.ledServer
